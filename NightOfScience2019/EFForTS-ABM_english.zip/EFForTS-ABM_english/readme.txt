
## INSTALLATION INSTRUCTIONS

EFForTS-ABM is implemented in NetLogo 5.3.1
This model will only work properly with NetLogo version 5.3.1.
The software is freely available and can be downloaded here:

https://ccl.northwestern.edu/netlogo/5.3.1/

EFForTS-ABM uses several NetLogo extensions that may not be bundled within NetLogo 5.3.1.
Extensions that have been used for this model are: gis, matrix, nw, table and xw.
The extension versions we used for this model are distributed within this model folder and should be found by NetLogo 5.3.1 automatically when the model is loaded.
However, in order to use these extenions in other models, the extension folders can also be copied to the NetLogo extensions folder which can be found here:

"..path.to.your.NetLogo.5.3.1.installation\app\extensions"


## CREDITS AND REFERENCES

Copyright 2017. Claudia Dislich, Elisabeth Hettig, Jan Salecker, Johannes Heinonen, Jann Lay, Katrin M. Meyer, Kerstin Wiegand, Suria Tarigan. All rights reserved.

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.

http://creativecommons.org/licenses/by-nc-nd/4.0/

Contact jsaleck(at)gwdg.de for license related questions.


This model is attached as supplementary material to the following publication:

Claudia Dislich, Elisabeth Hettig, Jan Salecker, Johannes Heinonen, Jann Lay, Katrin M. Meyer, Kerstin Wiegand, Suria Tarigan. in prep. Land-use change in oil palm dominated tropical landscapes - An agent-based model to explore ecological and socio-economic trade-offs